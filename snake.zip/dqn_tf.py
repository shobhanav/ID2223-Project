import os
#os.environ["CUDA_DEVICE_ORDER"] = "PCI_BUS_ID"   # see issue #152
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'

import sys
import numpy as np
import tensorflow as tf
import snake

class DQN:
    def __init__(self, sess, width, height, num_actions=4, num_replay=1000, name='qnet', log_dir=None):
        self.session = sess
        self.num_actions = num_actions
        self.width = width
        self.height = height
        self.dim = width*height
        self.num_replay = num_replay
        self.name = name

        # Layer size
        self.units = 256
        # Number of historical states to use for Q network input.
        self.phi_states = 3

        # Used for experience replay
        """
        self.replay_i = 0
        self.replay_a = -np.ones(self.num_replay, dtype=np.int8)
        self.replay_r = np.zeros(self.num_replay)
        self.replay_p = np.ones(self.num_replay)
        self.replay_terminal = np.zeros(self.num_replay, dtype=np.bool)
        self.replay_phi  = np.zeros((self.num_replay, self.phi_states, self.dim))
        self.replay_phi_ = np.zeros((self.num_replay, self.phi_states, self.dim))
        """

        #self.global_step = tf.Variable(0, trainable=False)
        self.create_graph()
        vars = tf.global_variables()
        self.saver = tf.train.Saver({var.name: var for var in vars}, max_to_keep=5)
        if log_dir:
            self.summary_writer = tf.summary.FileWriter(log_dir, graph=self.session.graph)


    # Simple network of 2 dense layers
    def create_graph(self):
        with tf.variable_scope(self.name):
            self.state = tf.placeholder(tf.float32, [None, self.phi_states, self.dim])

            flat = tf.reshape(self.state, shape=[-1, self.dim*self.phi_states])
            #l2_regularizer = tf.contrib.layers.l2_regularizer(1e-6)
            self.net = tf.layers.dense(
                inputs=flat,
                units=self.units*self.phi_states,
                activation=tf.nn.elu,
                activity_regularizer=tf.contrib.layers.l2_regularizer(1e-6)
            )
            self.net = tf.layers.dense(
                inputs=self.net,
                units=self.num_actions,
                activation=None, #linear
                activity_regularizer=tf.contrib.layers.l2_regularizer(1e-6)
            )

            self.y = tf.placeholder(tf.float32, shape=[None, self.num_actions])
            self.loss = tf.losses.mean_squared_error(self.y, self.net)
            self.optimizer = tf.train.AdamOptimizer().minimize(self.loss)
            self.q_values = tf.identity(self.net, name="q_values")
            self.predicted_actions = tf.argmax(self.q_values, axis=1 , name="predicted_actions")

            tf.summary.histogram("Q values", tf.reduce_mean(tf.reduce_max(self.q_values, 1)))
            tf.summary.scalar("loss", self.loss)
            # Merge all summaries into a single op
            self.summary_op = tf.summary.merge_all()

    def predict(self, state):
        x = np.reshape(state, [-1, 3,25])
        return self.session.run(self.net, feed_dict={self.state: x})

    def train_on_batch(self, xs, ys):
        return self.session.run([self.loss, self.optimizer, self.summary_op], {self.state: xs, self.y: ys})

    """
    def next_phi(self, g):
        s = g.board.reshape(self.units).copy()
        if self.phi is None:
            return [s]*self.phi_states
        else:
            self.phi.append(s)
            return self.phi[-self.phi_states:]

    # A replay tuple is (a, r, terminal, phi, phi_).
    def record(self, a, r, g):
        # Record in replay memory
        replay_i = (self.replay_i + 1) % self.num_replay
        if replay_i == 0:
            print('Replay buffer full, reset loop index')
        self.replay_a[replay_i] = a
        self.replay_r[replay_i] = r
        self.replay_p[replay_i] = self.replay_p.max()
        self.replay_terminal[replay_i] = g is None or g.is_over
        self.replay_phi[replay_i, :, :] = self.phi
        self.replay_phi_[replay_i, :, :] = self.phi_
        self.replay_i = replay_i
    """

    def copy_to(self, dst_net):
        v1 = self.variables()
        v2 = dst_net.variables()

        for i in range(len(v1)):
            v2[i].assign( v1[i] ).eval()

    def variables(self):
        return tf.get_collection(tf.GraphKeys.TRAINABLE_VARIABLES, self.name)


def state(g):
    w, h = g.board.shape
    #s = np.zeros(w*h + 1)
    #segs = (1.0 + np.array(g.segments).dot((1, w))) #/ float(w*h)
    #s[:segs.size] = segs
    #if np.any(g.board == snake.apple_i):
    #    s[-1] = (1.0 + g.random_cell(item=snake.apple).dot((1, w))) #/ float(w*h)
    return g.board.reshape(w*h).copy()

def q(phi, model):
    return model.predict(np.array([phi]))[0, :]

def main(args=sys.argv[1:], alpha=0.7, epsilon=5e-2, num_batch=50,
         num_copy_target=2000, num_iter=int(2e6), num_replay=int(1e6),
         replay_period=4, gamma=0.5, t_last_reward_max=25):

    #save_path, = args
    save_path = './checkpoints/dqn.ckpt'
    phi_states = 3
    # Used for experience replay
    replay_i = 0
    replay_a = -np.ones(num_replay, dtype=np.int8)
    replay_r = np.zeros(num_replay)
    replay_p = np.ones(num_replay)
    replay_terminal = np.zeros(num_replay, dtype=np.bool)
    replay_phi  = np.zeros((num_replay, phi_states, 5*5))
    replay_phi_ = np.zeros((num_replay, phi_states, 5*5))

    init_op = tf.global_variables_initializer()

    env = gym.make('Snake-v0', 10, 10)
    g = snake.game.from_size(model.width, model.height)

    with tf.Session() as sess:
    #with tf.device('/cpu:0'):
        model = DQN(sess, 5,5, num_actions=4,  name='qnet', log_dir='tensorboard')
        target = DQN(sess, 5,5, num_actions=4, name='target_qnet')

        checkpoint = tf.train.get_checkpoint_state(os.path.dirname(save_path))
        print(str(checkpoint))
        if checkpoint and checkpoint.model_checkpoint_path:
            print('Loading model...')
            model.saver.restore(sess, checkpoint.model_checkpoint_path)
            model.copy_to(target)
        else:
            sess.run(init_op)

        g, replay_i, Rtot, high_score = None, 0, 0, 0

        for i in range(num_iter):

            if g is None or g.is_over:
                g = snake.game.from_size(model.width, model.height)
                t, t_last_reward = 0, 0
                phi = [state(g)]*phi_states
                phi_ = list(phi)

            phi.append(state(g))
            phi = phi[-phi_states:]
            score = g.score

            # ε-greedy policy
            if np.random.random() < epsilon:
                a = np.random.choice(len(snake.dirs))
            else:
                a = q(phi, model).argmax()

            # Cast the dice!
            try:
                g.next(snake.dirs[a])
            except snake.GameOver as e:
                pass

            if g.score > high_score:
                high_score = g.score
                print('New high score:', high_score)

            phi_.append(state(g))
            phi_ = phi_[-phi_states:]
            r = float(-10 if g.is_over else g.score - score)

            # Track time of last reward. Abandon cowardly policies.
            t += 1
            t_last_reward = t if r > 0 else t_last_reward
            if t - t_last_reward >= t_last_reward_max:
                g = None

            Rtot += r

            # Record in replay memory
            #dqn.record(a, r, g)
            replay_i = (replay_i + 1) % num_replay
            if replay_i == 0:
                print('Replay buffer full, reset loop index')
            replay_a[replay_i] = a
            replay_r[replay_i] = r
            replay_p[replay_i] = replay_p.max()
            replay_terminal[replay_i] = g is None or g.is_over
            replay_phi[replay_i, :, :] = phi
            replay_phi_[replay_i, :, :] = phi_

            # Don't do learning until we have at least some experience, and only
            # each replay_period'th iteration.
            if i < num_batch or (i % replay_period) != 0:
                continue

            # Sample a minibatch
            jmax = min(i, num_replay)
            mb_idxs = np.random.choice(jmax, p=replay_p[:jmax]/replay_p[:jmax].sum(),
                                    size=num_batch, replace=False)
            mb_phi  = replay_phi[mb_idxs, :, :]
            mb_phi_ = replay_phi_[mb_idxs, :, :]
            mb_a    = replay_a[mb_idxs]
            mb_nonterm, = np.nonzero(replay_terminal[mb_idxs] == 0)

            # Predict Q of s and s_ for minibatch
            mb_q  = model.predict(mb_phi)
            mb_q_ = target.predict(mb_phi_)

            # Set targets for minibatch, setting the target for each
            # action-state to the predicted value, except for the chosen action
            # where we set it to what amounts to be the counterpart of the
            # Bellman equation: y_{j,a} = r_j + \gamma max_{a_} Q(s_, a_).
            mb_y = mb_q.copy()
            js = np.arange(mb_y.shape[0])
            mb_y[js,             mb_a]              = replay_r[mb_idxs]
            mb_y[js[mb_nonterm], mb_a[mb_nonterm]] += gamma*(mb_q_[mb_nonterm, :].max(axis=1))

            # Update TD error
            replay_p[mb_idxs] = (1.0 + np.abs(mb_y[js, mb_a] - mb_q[js, mb_a]))**alpha

            # Finally learn
            L, _, summary = model.train_on_batch(replay_phi[mb_idxs, :, :], mb_y)
            model.summary_writer.add_summary(summary, i * t * jmax)

            if (i % num_copy_target) == 0:
                model.copy_to(target)
                print(' -- Saving DQN --')
                print('        Average R:', Rtot/num_copy_target)
                print('       High score:', high_score)
                print('    Training loss:', L)
                print(' Minibatch mean Q:', np.r_[mb_q].mean(axis=0))
                print(' Minibatch mean y:', mb_y.mean(axis=0))
                # Save the variables to disk.
                model.saver.save(sess, save_path)

                Rtot = 0

    model.saver.save(sess, save_path)

if __name__ == "__main__":
    main()
