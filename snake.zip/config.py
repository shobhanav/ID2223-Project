class Config:
    width = 5
    height = 5
    directions = 'up down left right'.split()

    segment_score = 5
    apple_extension = 1

    # Number of historical states to use for Q network input.
    phi_states = 3

